/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appunab;

/**
 *
 * @author angel
 */
public class Curso {
    private String nombreMateria;
    private double notaFinal;

    public Curso(String nombreMateria, double notaFinal) {
        this.nombreMateria = nombreMateria;
        this.notaFinal = notaFinal;
    }

    public String getNombreMateria() { 
        return nombreMateria; 
    }

    public double getNotaFinal() { 
        return notaFinal; 
    }
    
    public String getEstado() {
        return (this.notaFinal >= 3.0) ? "Aprobado" : "Reprobado";
    }
}
