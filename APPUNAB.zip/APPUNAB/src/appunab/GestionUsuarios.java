package appunab;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class GestionUsuarios {
    private static GestionUsuarios instanciaUnica;
    private final ArrayList<Usuario> listaUsuarios;
    private final String RUTA_ARCHIVO = "usuarios.txt";
    private final String RUTA_NOTAS = "notas.txt";
    private final String RUTA_LOGROS = "logros.txt";
    private final String RUTA_LUGARES = "lugares.txt";
    private static final String RUTA_CALENDARIO = "calendario.txt";
    
    private Usuario buscarUsuarioPorCredenciales(String correo, String contrasenia) {
    for (Usuario u : listaUsuarios) {
        if (u.getCorreoInstitucional().equalsIgnoreCase(correo) && 
            u.getContrasenia().equals(contrasenia)) {
            return u;
        }
    }
    return null;
}   
    
    public Usuario obtenerUsuarioPorCredenciales(String correo, String contrasenia) {
    return buscarUsuarioPorCredenciales(correo, contrasenia);
}
    
    private GestionUsuarios() {
        this.listaUsuarios = new ArrayList<>();
        cargarUsuariosDesdeArchivo();
        cargarNotasDesdeArchivo();
        cargarCalendarioDesdeArchivo();
        cargarLogrosDesdeArchivo();
        cargarLugaresDesdeArchivo();
        for (Usuario u : listaUsuarios) {
        u.setLogrosDesbloqueados(u.getCantidadLogrosCompletados());
    }
    }
    public static synchronized GestionUsuarios getInstancia() {
    if (instanciaUnica == null) {
        instanciaUnica = new GestionUsuarios();
    }
    return instanciaUnica;
    }
    
    private void cargarNotasDesdeArchivo() {
        File archivo = new File(RUTA_NOTAS);
        if (!archivo.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(";");
                if (datos.length >= 3) {
                    String correoUsuario = datos[0];
                    String nombreMateria = datos[1];
                    double notaFinal = Double.parseDouble(datos[2]);

                    for (Usuario u : listaUsuarios) {
                        if (u.getCorreoInstitucional().equalsIgnoreCase(correoUsuario)) {
                            Curso c = new Curso(nombreMateria, notaFinal);
                            u.agregarCurso(c);
                            break; 
                        }
                    }
                }
            }
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error al cargar las notas: " + e.getMessage());
        }
    }

    public void guardarNuevaNota(String correo, Curso nuevoCurso) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(RUTA_NOTAS, true))) {
        String linea = correo + ";" + nuevoCurso.getNombreMateria() + ";" + nuevoCurso.getNotaFinal();
        bw.write(linea);
        bw.newLine();
    } catch (IOException e) {
        System.out.println("Error al persistir la nueva nota: " + e.getMessage());
    }
    for (Usuario u : listaUsuarios) {
        if (u.getCorreoInstitucional().equalsIgnoreCase(correo)) {
            u.agregarCurso(nuevoCurso);
            break;
        }
    }
    }   
    public boolean existeUsuario(String correo) {
        for (Usuario u : listaUsuarios) {
            if (u.getCorreoInstitucional().equalsIgnoreCase(correo)) {
                return true;
            }
        }
        return false;
    }
    public boolean registrarUsuario(Usuario nuevoUsuario) {
        if (existeUsuario(nuevoUsuario.getCorreoInstitucional())) {
            return false; 
        }
        listaUsuarios.add(nuevoUsuario);
        actualizarArchivoCompleto();
        inicializarLogrosParaNuevoUsuario(nuevoUsuario.getCorreoInstitucional());
        return true; 
    }
    public boolean validarInicioSesion(String correo, String contrasenia) {
    return buscarUsuarioPorCredenciales(correo, contrasenia) != null;
    }
    public void actualizarArchivoCompleto() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(RUTA_ARCHIVO, false))) { // false para sobrescribir el archivo completo
            for (Usuario u : listaUsuarios) {
                String linea = u.getNombreCompleto() + ";" 
                     + u.getCorreoInstitucional() + ";" 
                     + u.getContrasenia() + ";" 
                     + u.getPuntosApunab() + ";" 
                     + u.getRachaDias() + ";"
                     + u.getLogrosDesbloqueados() + ";" 
                     + u.getNivelActual() + ";"
                     + u.isEvento1Completado() + ";"
                     + u.isEvento2Completado() + ";"
                     + u.isEvento3Completado() + ";"
                     + u.getPuntosSemanales();
                    bw.write(linea);
                    bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error al actualizar la base de datos: " + e.getMessage());
        }
    }
    private void cargarUsuariosDesdeArchivo() {
   File archivo = new File(RUTA_ARCHIVO);
    if (!archivo.exists()) return;
    try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            String[] datos = linea.split(";");
            
            if (datos.length >= 3) {
                String nombre = datos[0];
                String correo = datos[1];
                String contrasenia = datos[2];
                int puntos = 0;
                int racha = 0;
                int logros = 0;
                int nivel = 1;
                
                if (datos.length >= 7) {
                    try {
                        puntos = Integer.parseInt(datos[3]);
                        racha = Integer.parseInt(datos[4]);
                        logros = Integer.parseInt(datos[5]);
                        nivel = Integer.parseInt(datos[6]);
                    } catch (NumberFormatException nfe) {
                        System.out.println("Formato numérico corrupto en línea, usando valores por defecto.");
                    }
                }
                
                Usuario u = new Usuario(nombre, correo, contrasenia, puntos, racha, logros, nivel);
                if (datos.length >= 10) {
                        u.setEvento1Completado(Boolean.parseBoolean(datos[7]));
                        u.setEvento2Completado(Boolean.parseBoolean(datos[8]));
                        u.setEvento3Completado(Boolean.parseBoolean(datos[9]));
                        if (datos.length >= 11) {  
                            try {
                                u.setPuntosSemanales(Integer.parseInt(datos[10]));
                                    } catch (NumberFormatException e) {
                                    u.setPuntosSemanales(0);  
    }
}
                    }
                listaUsuarios.add(u);
            }
        }
    } catch (IOException e) {
        System.out.println("Error al cargar la persistencia: " + e.getMessage());
    }    
    }
    private void cargarCalendarioDesdeArchivo() {
    File archivo = new File(RUTA_CALENDARIO);
    if (!archivo.exists()) return;

    try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            String[] datos = linea.split(";");
            if (datos.length >= 6) {
                String correoUsuario = datos[0];
                
                try {
                    int dia = Integer.parseInt(datos[1]);
                    int mes = Integer.parseInt(datos[2]);
                    int anio = Integer.parseInt(datos[3]);
                    String titulo = datos[4];
                    String tipo = datos[5];

                    for (Usuario u : listaUsuarios) {
                        if (u.getCorreoInstitucional().equalsIgnoreCase(correoUsuario)) {
                            EventoCalendario ev = new EventoCalendario(dia, mes, anio, titulo, tipo);
                            u.agregarEvento(ev);
                            break; 
                        }
                    }
                } catch (NumberFormatException nfe) {
                    System.out.println("Error en formato numérico de fecha en: " + linea);
                }
            }
        }
    } catch (IOException e) {
        System.out.println("Error al cargar el calendario: " + e.getMessage());
    }
    }
    public void recargarCursosParaUsuario(String correo) {
    Usuario usuarioObjetivo = null;
    for (Usuario u : listaUsuarios) {
        if (u.getCorreoInstitucional().equalsIgnoreCase(correo)) {
            usuarioObjetivo = u;
            break;
        }
    }
    if (usuarioObjetivo == null) return; 
    usuarioObjetivo.limpiarCursos();
    
    File archivo = new File(RUTA_NOTAS);
    if (!archivo.exists()) return;

    try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            String[] datos = linea.split(";");
            if (datos.length >= 3) {
                String correoUsuario = datos[0];
                if (correoUsuario.equalsIgnoreCase(correo)) {
                    String nombreMateria = datos[1];
                    double notaFinal = Double.parseDouble(datos[2]);
                    usuarioObjetivo.agregarCurso(new Curso(nombreMateria, notaFinal));
                }
            }
        }
        System.out.println(" Cursos recargados para: " + correo);
    } catch (IOException | NumberFormatException e) {
        System.out.println("Error al recargar cursos: " + e.getMessage());
    }
    }
    public void cargarLogrosDesdeArchivo() {
        File archivo = new File(RUTA_LOGROS);
        if (!archivo.exists()) return; 

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(";");
                if (datos.length >= 4) {
                    String correo = datos[0];
                    String nombre = datos[1];
                    String descripcion = datos[2];
                    boolean completado = Boolean.parseBoolean(datos[3]);

                    for (Usuario u : listaUsuarios) {
                        if (u.getCorreoInstitucional().equalsIgnoreCase(correo)) {
                            u.agregarLogro(new Logro(correo, nombre, descripcion, completado));
                            break;
                        }
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar logros desde archivo: " + e.getMessage());
        }
    }

    public void actualizarLogrosEnArchivo() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(RUTA_LOGROS, false))) {
            for (Usuario u : listaUsuarios) {
                for (Logro l : u.getListaLogros()) {
                    String linea = l.getCorreoUsuario() + ";" 
                                 + l.getNombreLogro() + ";" 
                                 + l.getDescripcion() + ";" 
                                 + l.isCompletado();
                    bw.write(linea);
                    bw.newLine();
                }
            }
        } catch (IOException e) {
            System.out.println("Error al escribir en logros.txt: " + e.getMessage());
        }
    }

    public void inicializarLogrosParaNuevoUsuario(String correo) {
        for (Usuario u : listaUsuarios) {
            if (u.getCorreoInstitucional().equalsIgnoreCase(correo)) {
                u.getListaLogros().clear(); // Limpieza preventiva para evitar duplicados
                u.agregarLogro(new Logro(correo, "Debutante", "Bienvenido a unab", false));
                u.agregarLogro(new Logro(correo, "Fuego inicial", "7 dias de racha", false));
                u.agregarLogro(new Logro(correo, "TOP 10", "Top 10 en ranking", false));
                u.agregarLogro(new Logro(correo, "Estrella", "Promedio mayor de 4.5", false));
                u.agregarLogro(new Logro(correo, "Responsable", "Completar todas las tareas", false));
                u.agregarLogro(new Logro(correo, "Regalo", "Toca aqui", false));
                break;
            }
        }
        actualizarLogrosEnArchivo();
    }
    private final void cargarLugaresDesdeArchivo() {
        File archivo = new File(RUTA_LUGARES);
        if (!archivo.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(";");

                if (datos.length >= 6) {
                    String correo = datos[0];
                    String tipo = datos[1];
                    String nombre = datos[2];
                    String ubicacion = datos[3];
                    String descripcion = datos[4];
                    String imagenPath = datos[5];
                    
                    for (Usuario u : listaUsuarios) {
                        if (u.getCorreoInstitucional().equalsIgnoreCase(correo)) {
                            Lugar lugar = new Lugar(nombre, ubicacion, descripcion, imagenPath, 
                                                   tipo.equals("CREADO") ? correo : null);
                            if (tipo.equals("INSCRITO")) {
                                u.inscribirseEnLugar(lugar);
                            } else if (tipo.equals("CREADO")) {
                                u.agregarLugarCreado(lugar);
                            }
                            break;
                        }
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar lugares: " + e.getMessage());
        }
    }
     public final void actualizarLugaresEnArchivo() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(RUTA_LUGARES, false))) {
            for (Usuario u : listaUsuarios) {
                String correo = u.getCorreoInstitucional();
                
                for (Lugar l : u.getLugaresInscritos()) {
                    String linea = correo + ";INSCRITO;" + l.getNombre() + ";" + 
                                  l.getUbicacion() + ";" + l.getDescripcion() + ";" + l.getImagenPath();
                    bw.write(linea);
                    bw.newLine();
                }
                
                for (Lugar l : u.getLugaresCreados()) {
                    String linea = correo + ";CREADO;" + l.getNombre() + ";" + 
                                  l.getUbicacion() + ";" + l.getDescripcion() + ";" + l.getImagenPath();
                    bw.write(linea);
                    bw.newLine();
                }
            }
        } catch (IOException e) {
            System.out.println("Error al escribir en lugares.txt: " + e.getMessage());
        }
    }
         public void guardarCambiosLugares(Usuario usuario) {
        actualizarArchivoCompleto();  
        actualizarLugaresEnArchivo();
    }
    
}