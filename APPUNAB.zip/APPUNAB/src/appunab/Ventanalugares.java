/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package appunab;

/**
 *
 * @author angel
 */
public class Ventanalugares extends javax.swing.JFrame {
    private final Usuario usuarioSesion;
    private GestionUsuarios gestion = GestionUsuarios.getInstancia();

    public Ventanalugares(Usuario usuarioLogueado) {
        this.usuarioSesion = usuarioLogueado;
        initComponents();
        if (this.usuarioSesion != null) {
            hola1.setText(this.usuarioSesion.getNombreCompleto());
            inicializarLugaresFijos();
            configurarPanel6();
        }
    }

    private void configurarPanel(javax.swing.JLabel nom, javax.swing.JLabel ubi, javax.swing.JLabel desc, 
                              javax.swing.JLabel img, javax.swing.JButton btn, Lugar lugar) {
        nom.setText(lugar.getNombre());
        ubi.setText(lugar.getUbicacion());
        desc.setText(lugar.getDescripcion());
        if (lugar.getImagenPath() != null) {
            try { img.setIcon(new javax.swing.ImageIcon(getClass().getResource(lugar.getImagenPath()))); } 
            catch (Exception e) {}
        }
        boolean inscrito = usuarioSesion.isInscritoEnLugar(lugar.getNombre());
        btn.setText(inscrito ? " Inscrito" : " Registrarse");
        btn.setForeground(inscrito ? new java.awt.Color(39,174,96) : new java.awt.Color(52,152,219));
        
        btn.addActionListener(e -> {
            String nombre = lugar.getNombre();
            if (usuarioSesion.isInscritoEnLugar(nombre)) {
                if (javax.swing.JOptionPane.showConfirmDialog(this, "¿Darse de baja de "+nombre+"?", "Confirmar", 
                    javax.swing.JOptionPane.YES_NO_OPTION) == javax.swing.JOptionPane.YES_OPTION) {
                    usuarioSesion.darseDeBajaDeLugar(nombre);
                    gestion.guardarCambiosLugares(usuarioSesion);
                    btn.setText(" Registrarse"); btn.setForeground(new java.awt.Color(52,152,219));
                }
            } else {
                usuarioSesion.inscribirseEnLugar(lugar);
                usuarioSesion.setPuntosApunab(usuarioSesion.getPuntosApunab() + 50);
                usuarioSesion.setPuntosSemanales(usuarioSesion.getPuntosSemanales() + 50);
                gestion.guardarCambiosLugares(usuarioSesion);
                gestion.actualizarArchivoCompleto();
                gestion.guardarCambiosLugares(usuarioSesion);
                gestion.actualizarArchivoCompleto();
                usuarioSesion.inscribirseEnLugar(lugar);
                usuarioSesion.setPuntosApunab(usuarioSesion.getPuntosApunab() + 50);
                gestion.guardarCambiosLugares(usuarioSesion);
                gestion.actualizarArchivoCompleto();
                btn.setText(" Inscrito"); btn.setForeground(new java.awt.Color(39,174,96));
                javax.swing.JOptionPane.showMessageDialog(this, "¡Inscrito en "+nombre+"!\n+50 APUNAB");
            }
        });
    }

    private void inicializarLugaresFijos() {
        Lugar[] fijos = {
            new Lugar("Plazoleta Central", "Edificio A, Piso 1", "Espacio de encuentro", "/imagenes/lugar1.png"),
            new Lugar("Cafetería CSU", "Bloque B", "Café y snacks", "/imagenes/lugar2.png"),
            new Lugar("Biblioteca Virtual", "Campus Digital", "Recursos 24/7", "/imagenes/lugar3.png"),
            new Lugar("Lab. Innovación", "Edificio C", "Espacio maker", "/imagenes/lugar4.png"),
            new Lugar("Auditorio Principal", "Bloque D", "Eventos y charlas", "/imagenes/lugar5.png")
        };
        configurarPanel(nombre1, ubicacion1, descripcion1, imagen1, boton1, fijos[0]);
        configurarPanel(nombre2, ubicacion2, descripcion2, imagen2, boton2, fijos[1]);
        configurarPanel(nombre3, ubicacion3, descripcion3, imagen3, boton3, fijos[2]);
        configurarPanel(nombre4, ubicacion4, descripcion4, imagen4, boton4, fijos[3]);
        configurarPanel(nombre5, ubicacion5, descripcion5, imagen5, boton5, fijos[4]);
    }


    private void configurarPanel6() {

        panel6EnModoAñadir();
        
        boton6.addActionListener(e -> {
            String nom = javax.swing.JOptionPane.showInputDialog(this, "Nombre del lugar:");
            String ubi = javax.swing.JOptionPane.showInputDialog(this, "Ubicación:");
            String desc = javax.swing.JOptionPane.showInputDialog(this, "Descripción:");
            
            if (nom != null && !nom.isEmpty() && ubi != null && !ubi.isEmpty()) {
                Lugar nuevo = new Lugar(nom, ubi, desc, "/imagenes/lugar1.png", usuarioSesion.getCorreoInstitucional());
                
                usuarioSesion.agregarLugarCreado(nuevo);
                usuarioSesion.inscribirseEnLugar(nuevo);
                usuarioSesion.setPuntosApunab(usuarioSesion.getPuntosApunab() + 100);
                usuarioSesion.setPuntosSemanales(usuarioSesion.getPuntosSemanales() + 100);
                gestion.guardarCambiosLugares(usuarioSesion);
                gestion.actualizarArchivoCompleto();
                
                panel6EnModoLugar(nuevo);
                
                javax.swing.JOptionPane.showMessageDialog(this, " ¡Lugar creado!\n+100 APUNAB");
            }
        });
    }

    private void panel6EnModoAñadir() {
        nombre6.setText(" Añadir nuevo lugar");
        ubicacion6.setText("Crea tu propio espacio");
        descripcion6.setText("Registra un lugar y compártelo");
        try { imagen6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/lugar6.png"))); } 
        catch (Exception e) { imagen6.setText("🏢"); }
        boton6.setText(" Añadir");
        boton6.setForeground(new java.awt.Color(155,89,182));
     
    }
    
    private void panel6EnModoLugar(Lugar lugar) {
        nombre6.setText(lugar.getNombre());
        ubicacion6.setText(lugar.getUbicacion());
        descripcion6.setText(lugar.getDescripcion());
        if (lugar.getImagenPath() != null) {
            try { imagen6.setIcon(new javax.swing.ImageIcon(getClass().getResource(lugar.getImagenPath()))); } 
            catch (Exception e) {}
        }
        
        boolean inscrito = usuarioSesion.isInscritoEnLugar(lugar.getNombre());
        boton6.setText(inscrito ? " Inscrito" : "Registrarse");
        boton6.setForeground(inscrito ? new java.awt.Color(39,174,96) : new java.awt.Color(52,152,219));

        boton6.addActionListener(e -> {
            String nombre = lugar.getNombre();
            Lugar lugarActual = usuarioSesion.buscarLugarPorNombre(nombre);
            if (lugarActual == null) return;
            
            if (usuarioSesion.isInscritoEnLugar(nombre)) {
                if (javax.swing.JOptionPane.showConfirmDialog(this, "¿Darse de baja de "+nombre+"?", "Confirmar", 
                    javax.swing.JOptionPane.YES_NO_OPTION) == javax.swing.JOptionPane.YES_OPTION) {
                    usuarioSesion.darseDeBajaDeLugar(nombre);
                    gestion.guardarCambiosLugares(usuarioSesion);
                    boton6.setText(" Registrarse"); boton6.setForeground(new java.awt.Color(52,152,219));
                }
            } else {
                usuarioSesion.inscribirseEnLugar(lugarActual);
                usuarioSesion.setPuntosSemanales(usuarioSesion.getPuntosSemanales() + 50);
                usuarioSesion.setPuntosApunab(usuarioSesion.getPuntosApunab() + 50);
                gestion.guardarCambiosLugares(usuarioSesion);
                gestion.guardarCambiosLugares(usuarioSesion);
                gestion.actualizarArchivoCompleto();
                boton6.setText(" Inscrito"); boton6.setForeground(new java.awt.Color(39,174,96));
                javax.swing.JOptionPane.showMessageDialog(this, "¡Inscrito en "+nombre+"!\n+50 APUNAB");
                gestion.actualizarArchivoCompleto();

            }
        });
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        icono1 = new javax.swing.JLabel();
        dashboard = new javax.swing.JButton();
        perfil = new javax.swing.JButton();
        cursos = new javax.swing.JButton();
        icono3 = new javax.swing.JLabel();
        notas = new javax.swing.JButton();
        icono4 = new javax.swing.JLabel();
        horario = new javax.swing.JButton();
        icono5 = new javax.swing.JLabel();
        calendario = new javax.swing.JButton();
        icono6 = new javax.swing.JLabel();
        logros = new javax.swing.JButton();
        icono7 = new javax.swing.JLabel();
        retos = new javax.swing.JButton();
        ranking = new javax.swing.JButton();
        icono9 = new javax.swing.JLabel();
        notificaciones = new javax.swing.JButton();
        cerrar = new javax.swing.JButton();
        icono11 = new javax.swing.JLabel();
        icono12 = new javax.swing.JLabel();
        icono10 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        hola = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        icono8 = new javax.swing.JLabel();
        icono13 = new javax.swing.JLabel();
        hola1 = new javax.swing.JLabel();
        Contenedorglobal = new javax.swing.JPanel();
        panel2 = new javax.swing.JPanel();
        imagen2 = new javax.swing.JLabel();
        boton2 = new javax.swing.JButton();
        nombre2 = new javax.swing.JLabel();
        ubicacion2 = new javax.swing.JLabel();
        descripcion2 = new javax.swing.JLabel();
        panel3 = new javax.swing.JPanel();
        imagen3 = new javax.swing.JLabel();
        boton3 = new javax.swing.JButton();
        nombre3 = new javax.swing.JLabel();
        ubicacion3 = new javax.swing.JLabel();
        descripcion3 = new javax.swing.JLabel();
        panel4 = new javax.swing.JPanel();
        imagen4 = new javax.swing.JLabel();
        nombre4 = new javax.swing.JLabel();
        ubicacion4 = new javax.swing.JLabel();
        descripcion4 = new javax.swing.JLabel();
        boton4 = new javax.swing.JButton();
        panel1 = new javax.swing.JPanel();
        imagen1 = new javax.swing.JLabel();
        nombre1 = new javax.swing.JLabel();
        ubicacion1 = new javax.swing.JLabel();
        descripcion1 = new javax.swing.JLabel();
        boton1 = new javax.swing.JButton();
        panel5 = new javax.swing.JPanel();
        imagen5 = new javax.swing.JLabel();
        nombre5 = new javax.swing.JLabel();
        ubicacion5 = new javax.swing.JLabel();
        descripcion5 = new javax.swing.JLabel();
        boton5 = new javax.swing.JButton();
        panel6 = new javax.swing.JPanel();
        imagen6 = new javax.swing.JLabel();
        nombre6 = new javax.swing.JLabel();
        ubicacion6 = new javax.swing.JLabel();
        descripcion6 = new javax.swing.JLabel();
        boton6 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 51, 204));
        jPanel1.setMinimumSize(new java.awt.Dimension(450, 320));
        jPanel1.setPreferredSize(new java.awt.Dimension(400, 320));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/apunab.png"))); // NOI18N
        jLabel1.setAlignmentX(0.5F);
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-40, 10, 460, 210));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, 360, 10));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/casita.png"))); // NOI18N
        jLabel4.setToolTipText("");
        jLabel4.setAlignmentX(0.5F);
        jLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel4.setMaximumSize(new java.awt.Dimension(100, 40));
        jLabel4.setMinimumSize(new java.awt.Dimension(100, 40));
        jLabel4.setName(""); // NOI18N
        jLabel4.setPreferredSize(new java.awt.Dimension(100, 40));
        jLabel4.setRequestFocusEnabled(false);
        jLabel4.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 260, 50, 60));

        icono1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/salida.png"))); // NOI18N
        icono1.setMaximumSize(new java.awt.Dimension(55, 60));
        icono1.setMinimumSize(new java.awt.Dimension(55, 60));
        icono1.setPreferredSize(new java.awt.Dimension(60, 60));
        jPanel1.add(icono1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 940, 50, 50));

        dashboard.setBackground(new java.awt.Color(51, 102, 255));
        dashboard.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        dashboard.setForeground(new java.awt.Color(255, 255, 255));
        dashboard.setText("Dashboard");
        dashboard.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        dashboard.addActionListener(this::dashboardActionPerformed);
        jPanel1.add(dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 260, 170, 60));

        perfil.setBackground(new java.awt.Color(0, 51, 255));
        perfil.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        perfil.setForeground(new java.awt.Color(255, 255, 255));
        perfil.setText("Perfil");
        perfil.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        perfil.addActionListener(this::perfilActionPerformed);
        jPanel1.add(perfil, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 350, -1, -1));

        cursos.setBackground(new java.awt.Color(0, 51, 255));
        cursos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cursos.setForeground(new java.awt.Color(255, 255, 255));
        cursos.setText("Cursos");
        cursos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cursos.addActionListener(this::cursosActionPerformed);
        jPanel1.add(cursos, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 410, -1, -1));

        icono3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/libro.png"))); // NOI18N
        icono3.setMaximumSize(new java.awt.Dimension(55, 60));
        icono3.setMinimumSize(new java.awt.Dimension(55, 60));
        icono3.setPreferredSize(new java.awt.Dimension(60, 60));
        jPanel1.add(icono3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 400, 50, 40));

        notas.setBackground(new java.awt.Color(0, 51, 255));
        notas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        notas.setForeground(new java.awt.Color(255, 255, 255));
        notas.setText("Lugares");
        notas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        notas.addActionListener(this::notasActionPerformed);
        jPanel1.add(notas, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 470, -1, -1));

        icono4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/maksa.png"))); // NOI18N
        icono4.setMaximumSize(new java.awt.Dimension(55, 60));
        icono4.setMinimumSize(new java.awt.Dimension(55, 60));
        icono4.setPreferredSize(new java.awt.Dimension(60, 60));
        jPanel1.add(icono4, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 460, 50, 50));

        horario.setBackground(new java.awt.Color(0, 51, 255));
        horario.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        horario.setForeground(new java.awt.Color(255, 255, 255));
        horario.setText("Estadisticas");
        horario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        horario.addActionListener(this::horarioActionPerformed);
        jPanel1.add(horario, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 540, -1, -1));

        icono5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/flan.png"))); // NOI18N
        icono5.setMaximumSize(new java.awt.Dimension(55, 60));
        icono5.setMinimumSize(new java.awt.Dimension(55, 60));
        icono5.setPreferredSize(new java.awt.Dimension(60, 60));
        jPanel1.add(icono5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 520, 50, 50));

        calendario.setBackground(new java.awt.Color(0, 51, 255));
        calendario.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        calendario.setForeground(new java.awt.Color(255, 255, 255));
        calendario.setText("Calendario");
        calendario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        calendario.addActionListener(this::calendarioActionPerformed);
        jPanel1.add(calendario, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 610, -1, -1));

        icono6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/calen.png"))); // NOI18N
        icono6.setMaximumSize(new java.awt.Dimension(55, 60));
        icono6.setMinimumSize(new java.awt.Dimension(55, 60));
        icono6.setPreferredSize(new java.awt.Dimension(60, 60));
        jPanel1.add(icono6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 590, 60, 50));

        logros.setBackground(new java.awt.Color(0, 51, 255));
        logros.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        logros.setForeground(new java.awt.Color(255, 255, 255));
        logros.setText("Logros");
        logros.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        logros.addActionListener(this::logrosActionPerformed);
        jPanel1.add(logros, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 680, -1, -1));

        icono7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/logro.png"))); // NOI18N
        icono7.setMaximumSize(new java.awt.Dimension(55, 60));
        icono7.setMinimumSize(new java.awt.Dimension(55, 60));
        icono7.setPreferredSize(new java.awt.Dimension(60, 60));
        jPanel1.add(icono7, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 660, 50, 50));

        retos.setBackground(new java.awt.Color(0, 51, 255));
        retos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        retos.setForeground(new java.awt.Color(255, 255, 255));
        retos.setText("Retos");
        jPanel1.add(retos, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 750, -1, -1));

        ranking.setBackground(new java.awt.Color(0, 51, 255));
        ranking.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ranking.setForeground(new java.awt.Color(255, 255, 255));
        ranking.setText("Ranking");
        jPanel1.add(ranking, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 810, -1, -1));

        icono9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/randek .png"))); // NOI18N
        icono9.setMaximumSize(new java.awt.Dimension(55, 60));
        icono9.setMinimumSize(new java.awt.Dimension(55, 60));
        icono9.setPreferredSize(new java.awt.Dimension(60, 60));
        jPanel1.add(icono9, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 790, 50, 50));

        notificaciones.setBackground(new java.awt.Color(0, 51, 255));
        notificaciones.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        notificaciones.setForeground(new java.awt.Color(255, 255, 255));
        notificaciones.setText("Notificaciones");
        jPanel1.add(notificaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 870, -1, -1));

        cerrar.setBackground(new java.awt.Color(0, 51, 255));
        cerrar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cerrar.setForeground(new java.awt.Color(255, 255, 255));
        cerrar.setText("Cerrar sesion");
        jPanel1.add(cerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 950, -1, -1));

        icono11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/tinker.png"))); // NOI18N
        icono11.setMaximumSize(new java.awt.Dimension(55, 60));
        icono11.setMinimumSize(new java.awt.Dimension(55, 60));
        icono11.setPreferredSize(new java.awt.Dimension(60, 60));
        jPanel1.add(icono11, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 850, 50, 50));

        icono12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mando.png"))); // NOI18N
        icono12.setMaximumSize(new java.awt.Dimension(55, 60));
        icono12.setMinimumSize(new java.awt.Dimension(55, 60));
        icono12.setPreferredSize(new java.awt.Dimension(60, 60));
        jPanel1.add(icono12, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 730, 50, 50));

        icono10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/IconoPerfil.png"))); // NOI18N
        icono10.setMaximumSize(new java.awt.Dimension(55, 60));
        icono10.setMinimumSize(new java.awt.Dimension(55, 60));
        icono10.setPreferredSize(new java.awt.Dimension(60, 60));
        jPanel1.add(icono10, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 330, 50, 50));

        getContentPane().add(jPanel1, java.awt.BorderLayout.LINE_START);

        jPanel2.setBackground(new java.awt.Color(232, 240, 255));
        jPanel2.setPreferredSize(new java.awt.Dimension(2000, 975));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        hola.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        hola.setText("Ver lugares unab ");
        jPanel2.add(hola, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 40, 320, 70));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setText("Espacios reservables");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(56, 132, -1, 33));

        icono8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/blancteo.png"))); // NOI18N
        icono8.setMaximumSize(new java.awt.Dimension(55, 60));
        icono8.setMinimumSize(new java.awt.Dimension(55, 60));
        icono8.setPreferredSize(new java.awt.Dimension(60, 60));
        jPanel2.add(icono8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 60, 50, 50));

        icono13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/blanca (1).png"))); // NOI18N
        icono13.setMaximumSize(new java.awt.Dimension(55, 60));
        icono13.setMinimumSize(new java.awt.Dimension(55, 60));
        icono13.setPreferredSize(new java.awt.Dimension(60, 60));
        jPanel2.add(icono13, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 60, 50, 50));

        hola1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        hola1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        hola1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hola1MouseClicked(evt);
            }
        });
        jPanel2.add(hola1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 50, 420, 70));

        Contenedorglobal.setBackground(new java.awt.Color(255, 255, 255));
        Contenedorglobal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        imagen2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/elele.png"))); // NOI18N
        panel2.add(imagen2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 260, 120));

        boton2.setBackground(new java.awt.Color(0, 51, 204));
        boton2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        boton2.setForeground(new java.awt.Color(255, 255, 255));
        boton2.setText("Registrarse");
        panel2.add(boton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 240, 160, 40));

        nombre2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        nombre2.setText("Cafeteria L");
        panel2.add(nombre2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        ubicacion2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ubicacion2.setText("El jardin");
        panel2.add(ubicacion2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, -1, -1));

        descripcion2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        descripcion2.setText("Pausas guiadas y pequeñas dinamicas");
        panel2.add(descripcion2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, -1, 20));

        Contenedorglobal.add(panel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 40, 380, 300));

        panel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        imagen3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/csu.png"))); // NOI18N
        panel3.add(imagen3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 260, 120));

        boton3.setBackground(new java.awt.Color(0, 51, 204));
        boton3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        boton3.setForeground(new java.awt.Color(255, 255, 255));
        boton3.setText("Registrarse");
        panel3.add(boton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 240, 160, 40));

        nombre3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        nombre3.setText("Plazoleta CSU");
        panel3.add(nombre3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        ubicacion3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ubicacion3.setText("Centro de servicios universitarios");
        panel3.add(ubicacion3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, -1, -1));

        descripcion3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        descripcion3.setText("Bienestar universitario y talleres institucionales");
        panel3.add(descripcion3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, -1, 20));

        Contenedorglobal.add(panel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 40, 380, 300));

        panel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        imagen4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/carlos.png"))); // NOI18N
        panel4.add(imagen4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 280, 120));

        nombre4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        nombre4.setText("Biblioteca Luis Carlos");
        panel4.add(nombre4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        ubicacion4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ubicacion4.setText("El jardin");
        panel4.add(ubicacion4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, -1, -1));

        descripcion4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        descripcion4.setText("Talleres y lecturas guiadas");
        panel4.add(descripcion4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, -1, 20));

        boton4.setBackground(new java.awt.Color(0, 51, 204));
        boton4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        boton4.setForeground(new java.awt.Color(255, 255, 255));
        boton4.setText("Registrarse");
        panel4.add(boton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 240, 160, 40));

        Contenedorglobal.add(panel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 390, 380, 300));

        panel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        imagen1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/plazo (6).png"))); // NOI18N
        panel1.add(imagen1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 280, 120));

        nombre1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        nombre1.setText("Plazoleta banu");
        panel1.add(nombre1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        ubicacion1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ubicacion1.setText("El jardin");
        panel1.add(ubicacion1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, -1, -1));

        descripcion1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        descripcion1.setText("Punto de eventos, ferias APUNAB y actividades generales");
        panel1.add(descripcion1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, -1, 20));

        boton1.setBackground(new java.awt.Color(0, 51, 204));
        boton1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        boton1.setForeground(new java.awt.Color(255, 255, 255));
        boton1.setText("Registrarse");
        panel1.add(boton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 240, 160, 40));

        Contenedorglobal.add(panel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, 380, 300));

        panel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        imagen5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/torre.png"))); // NOI18N
        panel5.add(imagen5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 280, 120));

        nombre5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        nombre5.setText("Plazoleta principal");
        panel5.add(nombre5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        ubicacion5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ubicacion5.setText("El jardin");
        panel5.add(ubicacion5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, -1, -1));

        descripcion5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        descripcion5.setText("Eventos sociales y actividades de integracion");
        panel5.add(descripcion5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, -1, 20));

        boton5.setBackground(new java.awt.Color(0, 51, 204));
        boton5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        boton5.setForeground(new java.awt.Color(255, 255, 255));
        boton5.setText("Registrarse");
        panel5.add(boton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 240, 160, 40));

        Contenedorglobal.add(panel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 390, 380, 300));

        panel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        imagen6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/torre.png"))); // NOI18N
        panel6.add(imagen6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 280, 120));

        nombre6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        panel6.add(nombre6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 320, 30));

        ubicacion6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        panel6.add(ubicacion6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 320, 20));

        descripcion6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        panel6.add(descripcion6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, 330, 20));

        boton6.setBackground(new java.awt.Color(0, 51, 204));
        boton6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        boton6.setForeground(new java.awt.Color(255, 255, 255));
        boton6.setText("Registrarse");
        panel6.add(boton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 240, 160, 40));

        Contenedorglobal.add(panel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 390, 380, 300));

        jPanel2.add(Contenedorglobal, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, 1460, 740));

        getContentPane().add(jPanel2, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void dashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashboardActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dashboardActionPerformed

    private void perfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_perfilActionPerformed
        Ventanperfil perfil = new Ventanperfil(this.usuarioSesion);

        perfil.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);

        perfil.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_perfilActionPerformed

    private void cursosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cursosActionPerformed
        Ventananotas notas = new Ventananotas(this.usuarioSesion);
        notas.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        notas.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_cursosActionPerformed

    private void notasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_notasActionPerformed
        Ventanalugares lugar = new Ventanalugares(this.usuarioSesion);
        lugar.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        lugar.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_notasActionPerformed

    private void horarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_horarioActionPerformed
        Ventanaestadisticas estadistica = new Ventanaestadisticas(this.usuarioSesion);
        estadistica.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        estadistica.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_horarioActionPerformed

    private void calendarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calendarioActionPerformed
        Ventanacalendario calendario = new Ventanacalendario(this.usuarioSesion);
        calendario.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        calendario.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_calendarioActionPerformed

    private void logrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logrosActionPerformed
        Ventanalogros logros = new Ventanalogros(this.usuarioSesion);
        logros.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        logros.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_logrosActionPerformed

    private void hola1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hola1MouseClicked

        Ventanperfil perfil = new Ventanperfil(this.usuarioSesion);

        perfil.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);

        perfil.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_hola1MouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Contenedorglobal;
    private javax.swing.JButton boton1;
    private javax.swing.JButton boton2;
    private javax.swing.JButton boton3;
    private javax.swing.JButton boton4;
    private javax.swing.JButton boton5;
    private javax.swing.JButton boton6;
    private javax.swing.JButton calendario;
    private javax.swing.JButton cerrar;
    private javax.swing.JButton cursos;
    private javax.swing.JButton dashboard;
    private javax.swing.JLabel descripcion1;
    private javax.swing.JLabel descripcion2;
    private javax.swing.JLabel descripcion3;
    private javax.swing.JLabel descripcion4;
    private javax.swing.JLabel descripcion5;
    private javax.swing.JLabel descripcion6;
    private javax.swing.JLabel hola;
    private javax.swing.JLabel hola1;
    private javax.swing.JButton horario;
    private javax.swing.JLabel icono1;
    private javax.swing.JLabel icono10;
    private javax.swing.JLabel icono11;
    private javax.swing.JLabel icono12;
    private javax.swing.JLabel icono13;
    private javax.swing.JLabel icono3;
    private javax.swing.JLabel icono4;
    private javax.swing.JLabel icono5;
    private javax.swing.JLabel icono6;
    private javax.swing.JLabel icono7;
    private javax.swing.JLabel icono8;
    private javax.swing.JLabel icono9;
    private javax.swing.JLabel imagen1;
    private javax.swing.JLabel imagen2;
    private javax.swing.JLabel imagen3;
    private javax.swing.JLabel imagen4;
    private javax.swing.JLabel imagen5;
    private javax.swing.JLabel imagen6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JButton logros;
    private javax.swing.JLabel nombre1;
    private javax.swing.JLabel nombre2;
    private javax.swing.JLabel nombre3;
    private javax.swing.JLabel nombre4;
    private javax.swing.JLabel nombre5;
    private javax.swing.JLabel nombre6;
    private javax.swing.JButton notas;
    private javax.swing.JButton notificaciones;
    private javax.swing.JPanel panel1;
    private javax.swing.JPanel panel2;
    private javax.swing.JPanel panel3;
    private javax.swing.JPanel panel4;
    private javax.swing.JPanel panel5;
    private javax.swing.JPanel panel6;
    private javax.swing.JButton perfil;
    private javax.swing.JButton ranking;
    private javax.swing.JButton retos;
    private javax.swing.JLabel ubicacion1;
    private javax.swing.JLabel ubicacion2;
    private javax.swing.JLabel ubicacion3;
    private javax.swing.JLabel ubicacion4;
    private javax.swing.JLabel ubicacion5;
    private javax.swing.JLabel ubicacion6;
    // End of variables declaration//GEN-END:variables
}