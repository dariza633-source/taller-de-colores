/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appunab;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class Usuario {
    private String usuario;
    private String correoInstitucional;
    private String contrasenia;


    private int puntosApunab;
    private int rachaDias;
    private int logrosDesbloqueados;
    private int nivelActual;
    private ArrayList<Curso> listaCursos;
    private ArrayList<EventoCalendario> listaEventos;
    private ArrayList<Logro> listaLogros;
    private ArrayList<Lugar> lugaresInscritos;  
    private ArrayList<Lugar> lugaresCreados;     
    private boolean evento1Completado;
    private boolean evento2Completado;
    private boolean evento3Completado;
    private int puntosSemanales = 0; 
    

    public Usuario(String usuario, String correoInstitucional, String contrasenia, int puntos, int racha, int logros, int nivel) {
        this.usuario = usuario;
        this.correoInstitucional = correoInstitucional;
        this.contrasenia = contrasenia;
        this.puntosApunab = puntos;
        this.rachaDias = racha;
        this.logrosDesbloqueados = logros;
        this.nivelActual = nivel;
        this.listaCursos = new ArrayList<>();
        this.listaEventos = new ArrayList<>();
        this.listaLogros = new ArrayList<>();
        this.lugaresInscritos = new ArrayList<>();
        this.lugaresCreados = new ArrayList<>();
        this.evento1Completado = false;
        this.evento2Completado = false;
        this.evento3Completado = false;
    }

    public String getNombreCompleto() { return usuario; }
    public String getCorreoInstitucional() { return correoInstitucional; }
    public String getContrasenia() { return contrasenia; }
    
    public int getPuntosApunab() { return puntosApunab; }
    public int getRachaDias() { return rachaDias; }
    public int getLogrosDesbloqueados() { return logrosDesbloqueados; }
    public int getNivelActual() { return nivelActual; }
    public void setPuntosApunab(int puntosApunab) {
    this.puntosApunab = puntosApunab;
    }
    public List<Curso> getListaCursos() {
    return Collections.unmodifiableList(listaCursos);
}   
    public void agregarCurso(Curso nuevoCurso) {
        this.listaCursos.add(nuevoCurso);
    }
    public List<EventoCalendario> getListaEventos() {
    return Collections.unmodifiableList(listaEventos);
    }
    public void agregarEvento(EventoCalendario ev) {
    this.listaEventos.add(ev);
    }
    public boolean isEvento1Completado() { return evento1Completado; }
    public void setEvento1Completado(boolean estado) { this.evento1Completado = estado; }

    public boolean isEvento2Completado() { return evento2Completado; }
    public void setEvento2Completado(boolean estado) { this.evento2Completado = estado; }

    public boolean isEvento3Completado() { return evento3Completado; }
    public void setEvento3Completado(boolean estado) { this.evento3Completado = estado; }
    public int getPuntosSemanales() { return puntosSemanales; }
    public void setPuntosSemanales(int p) { this.puntosSemanales = p; }
     public double calcularPromedioGeneral() {
        if (this.listaCursos == null || this.listaCursos.isEmpty()) {
            return 0.0;
        }
        
        double suma = 0;
        for (Curso c : this.listaCursos) {
            suma += c.getNotaFinal();
        }
        
        
        return Math.round((suma / this.listaCursos.size()) * 10.0) / 10.0;
     }

    public int getPuntosFaltantesGraduacion() { 
    int meta = 100000;
    int faltantes = meta - this.puntosApunab; 
    return Math.max(0, faltantes); 
    }

 
    public String getEstadisticasPromediosHTML() {

    final double AÑOS_CURSADOS = 1.5;
    final int SEMESTRES_POR_AÑO = 2;
    final int MESES_POR_SEMESTRE = 4;
    final int SEMANAS_POR_MES = 4;
    
    int totalPuntos = this.puntosApunab;
    double promAnio = totalPuntos / AÑOS_CURSADOS;
    double promSemestre = totalPuntos / (AÑOS_CURSADOS * SEMESTRES_POR_AÑO);
    double promMes = promSemestre / MESES_POR_SEMESTRE;
    double promSemana = promMes / SEMANAS_POR_MES;

    return new StringBuilder()
        .append("<html><body style='font-family:sans-serif;padding:8px;color:#2C3E50;'>")
        .append("<h3 style='margin:0 0 12px 0;font-size:14px;text-align:center;'>PROMEDIOS HISTÓRICOS</h3>")
        .append("<table style='width:100%;border-collapse:collapse;font-size:12px;'>")
        .append(filaEstadistica("Por Semana:", promSemana))
        .append(filaEstadistica("Por Mes:", promMes))
        .append(filaEstadistica("Por Semestre:", promSemestre))
        .append(filaEstadistica("Por Año:", promAnio))
        .append("</table></body></html>")
        .toString();
}

private String filaEstadistica(String etiqueta, double valor) {
    return String.format(
        "<tr style='border-bottom:1px solid #F0F0F0;'><td style='padding:6px 0;'><b>%s</b></td>" +
        "<td style='text-align:right;color:#27AE60;'><b>%.1f pts</b></td></tr>",
        etiqueta, valor
    );
}
public void setRachaDias(int rachaDias) {
        this.rachaDias = rachaDias;
    }

    public void registrarActividadRacha() {
        this.rachaDias = this.rachaDias + 1;
        
        appunab.GestionUsuarios.getInstancia().actualizarArchivoCompleto();
    }

    public String getRachaFormateada() {
        return this.rachaDias + " días";
    }
    void limpiarCursos() {
    this.listaCursos.clear();
}
    public void agregarLogro(Logro nuevoLogro) {
        this.listaLogros.add(nuevoLogro);
    }

    public ArrayList<Logro> getListaLogros() {
        return this.listaLogros;
    }

    public Logro buscarLogro(String nombre) {
        for (Logro l : this.listaLogros) {
            if (l.getNombreLogro().equalsIgnoreCase(nombre)) {
                return l;
            }
        }
        return null; 
    }

    public int getCantidadLogrosCompletados() {
        int contador = 0;
        for (Logro l : this.listaLogros) {
            if (l.isCompletado()) {
                contador++;
            }
        }
        return contador;
    }
    public void evaluarYRecompensarLogros() {
        this.logrosDesbloqueados = getCantidadLogrosCompletados();
        System.out.println("🔍 [USUARIO] Después de evaluar: campo = " + this.logrosDesbloqueados + " | conteo real = " + getCantidadLogrosCompletados());
        boolean huboCambio = false;
        StringBuilder mensajeLogros = new StringBuilder();

        Logro l1 = buscarLogro("Debutante");
        if (l1 != null && !l1.isCompletado()) {
            l1.setCompletado(true);
            this.puntosApunab += 500;
            mensajeLogros.append("• ¡Debutante! (+500 pts)\n");
            huboCambio = true;
        }

        Logro l2 = buscarLogro("Fuego inicial");
        if (l2 != null && !l2.isCompletado() && this.rachaDias >= 7) {
            l2.setCompletado(true);
            this.puntosApunab += 1000; 
            mensajeLogros.append("• ¡Fuego inicial! (+1000 pts)\n");
            huboCambio = true;
        }

        Logro l3 = buscarLogro("TOP 10");
        if (l3 != null && !l3.isCompletado() && this.nivelActual >= 3) {
            l3.setCompletado(true);
            this.puntosApunab += 1500; 
            mensajeLogros.append("• ¡TOP 10! (+1500 pts)\n");
            huboCambio = true;
        }

        Logro l4 = buscarLogro("Estrella");
        if (l4 != null && !l4.isCompletado() && this.calcularPromedioGeneral() >= 4.5) {
            l4.setCompletado(true);
            this.puntosApunab += 2000; 
            mensajeLogros.append("• ¡Estrella! (+2000 pts)\n");
            huboCambio = true;
        }

        if (huboCambio) {
            GestionUsuarios.getInstancia().actualizarArchivoCompleto();
            String correo = this.correoInstitucional;
            GestionUsuarios.getInstancia().actualizarLogrosEnArchivo();
            
            javax.swing.JOptionPane.showMessageDialog(
                null, 
               "¡Feclidades! se desbloquearon los logros: \n\n" + mensajeLogros.toString() + "\n¡Tus puntos e interfaz han sido actualizados!", 
                "Sistema de Logros APUNAB", 
                javax.swing.JOptionPane.INFORMATION_MESSAGE
            );
        }
    }
    public void setLogrosDesbloqueados(int logrosDesbloqueados) {
    this.logrosDesbloqueados = logrosDesbloqueados;
}
      public List<Lugar> getLugaresInscritos() {
        return Collections.unmodifiableList(lugaresInscritos);
    }
    
    public List<Lugar> getLugaresCreados() {
        return Collections.unmodifiableList(lugaresCreados);
    }
    
    public boolean isInscritoEnLugar(String nombreLugar) {
        for (Lugar l : lugaresInscritos) {
            if (l.getNombre().equalsIgnoreCase(nombreLugar)) {
                return true;
            }
        }
        return false;
    }
    
    public void inscribirseEnLugar(Lugar lugar) {
        if (!isInscritoEnLugar(lugar.getNombre())) {
            lugaresInscritos.add(lugar);
        }
    }
    
    public void darseDeBajaDeLugar(String nombreLugar) {
        lugaresInscritos.removeIf(l -> l.getNombre().equalsIgnoreCase(nombreLugar));
    }
    
    public void agregarLugarCreado(Lugar lugar) {
        lugaresCreados.add(lugar);
    }
    
    public void eliminarLugarCreado(String nombreLugar) {
        lugaresCreados.removeIf(l -> l.getNombre().equalsIgnoreCase(nombreLugar));
    }
    
    public Lugar buscarLugarPorNombre(String nombre) {
        for (Lugar l : lugaresInscritos) {
            if (l.getNombre().equalsIgnoreCase(nombre)) return l;
        }
        for (Lugar l : lugaresCreados) {
            if (l.getNombre().equalsIgnoreCase(nombre)) return l;
        }
        return null;
    }
}