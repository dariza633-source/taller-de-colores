package appunab;

public class Logro {
    private String correoUsuario; 
    private String nombreLogro; 
    private String descripcion; 
    private boolean completado;   

    public Logro(String correoUsuario, String nombreLogro, String descripcion, boolean completado) {
        this.correoUsuario = correoUsuario;
        this.nombreLogro = nombreLogro;
        this.descripcion = descripcion;
        this.completado = completado;
    }

    public String getCorreoUsuario() {
        return correoUsuario;
    }

    public void setCorreoUsuario(String correoUsuario) {
        this.correoUsuario = correoUsuario;
    }

    public String getNombreLogro() {
        return nombreLogro;
    }

    public void setNombreLogro(String nombreLogro) {
        this.nombreLogro = nombreLogro;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isCompletado() {
        return completado;
    }

    public void setCompletado(boolean completado) {
        this.completado = completado;
    }
}