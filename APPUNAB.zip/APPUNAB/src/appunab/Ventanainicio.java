/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package appunab;


public class Ventanainicio extends javax.swing.JFrame {
    
    
     private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Ventanainicio.class.getName());

    public Ventanainicio() {
        initComponents();
        this.setLocationRelativeTo(null);
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        PanelContenedor = new javax.swing.JPanel();
        IconoAPUNAB = new javax.swing.JLabel();
        Espacio1 = new javax.swing.JLabel();
        ContenedorIcono = new javax.swing.JPanel();
        icono = new javax.swing.JLabel();
        espacio4 = new javax.swing.JLabel();
        username = new javax.swing.JTextField();
        Espacio2 = new javax.swing.JLabel();
        contenedorr = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        espacio5 = new javax.swing.JLabel();
        Contraseña = new javax.swing.JPasswordField();
        Espacio3 = new javax.swing.JLabel();
        Inciairseiosn = new javax.swing.JButton();
        contenedorcontra = new javax.swing.JPanel();
        olvidosu = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 51, 255));
        jPanel1.setLayout(new java.awt.GridBagLayout());

        PanelContenedor.setBackground(new java.awt.Color(0, 51, 255));
        PanelContenedor.setForeground(new java.awt.Color(0, 51, 204));
        PanelContenedor.setName(""); // NOI18N
        PanelContenedor.setLayout(new javax.swing.BoxLayout(PanelContenedor, javax.swing.BoxLayout.Y_AXIS));

        IconoAPUNAB.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        IconoAPUNAB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/apunab.png"))); // NOI18N
        IconoAPUNAB.setAlignmentX(0.5F);
        IconoAPUNAB.setMaximumSize(new java.awt.Dimension(1000, 300));
        PanelContenedor.add(IconoAPUNAB);

        Espacio1.setMaximumSize(new java.awt.Dimension(10, 20));
        Espacio1.setMinimumSize(new java.awt.Dimension(10, 20));
        Espacio1.setPreferredSize(new java.awt.Dimension(10, 20));
        PanelContenedor.add(Espacio1);

        ContenedorIcono.setOpaque(false);
        ContenedorIcono.setLayout(new javax.swing.BoxLayout(ContenedorIcono, javax.swing.BoxLayout.X_AXIS));

        icono.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/IconoPerfil.png"))); // NOI18N
        icono.setMaximumSize(new java.awt.Dimension(50, 60));
        icono.setMinimumSize(new java.awt.Dimension(50, 60));
        icono.setPreferredSize(new java.awt.Dimension(50, 60));
        ContenedorIcono.add(icono);

        espacio4.setMaximumSize(new java.awt.Dimension(10, 60));
        espacio4.setMinimumSize(new java.awt.Dimension(10, 60));
        espacio4.setPreferredSize(new java.awt.Dimension(10, 60));
        ContenedorIcono.add(espacio4);

        username.setBackground(new java.awt.Color(0, 51, 255));
        username.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        username.setForeground(new java.awt.Color(255, 255, 255));
        username.setText("Correo");
        username.setBorder(null);
        username.setMaximumSize(new java.awt.Dimension(1460, 60));
        username.setMinimumSize(new java.awt.Dimension(1460, 60));
        username.setPreferredSize(new java.awt.Dimension(450, 55));
        username.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                usernameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                usernameFocusLost(evt);
            }
        });
        username.addActionListener(this::usernameActionPerformed);
        ContenedorIcono.add(username);

        PanelContenedor.add(ContenedorIcono);

        Espacio2.setMaximumSize(new java.awt.Dimension(10, 30));
        Espacio2.setMinimumSize(new java.awt.Dimension(10, 30));
        Espacio2.setPreferredSize(new java.awt.Dimension(10, 30));
        PanelContenedor.add(Espacio2);

        contenedorr.setBackground(new java.awt.Color(0, 51, 255));
        contenedorr.setLayout(new javax.swing.BoxLayout(contenedorr, javax.swing.BoxLayout.X_AXIS));

        jLabel1.setBackground(new java.awt.Color(0, 51, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/candadito.png"))); // NOI18N
        jLabel1.setMaximumSize(new java.awt.Dimension(50, 60));
        jLabel1.setMinimumSize(new java.awt.Dimension(50, 60));
        jLabel1.setPreferredSize(new java.awt.Dimension(50, 60));
        contenedorr.add(jLabel1);

        espacio5.setBackground(new java.awt.Color(0, 51, 255));
        espacio5.setMaximumSize(new java.awt.Dimension(10, 60));
        espacio5.setMinimumSize(new java.awt.Dimension(10, 60));
        espacio5.setOpaque(true);
        espacio5.setPreferredSize(new java.awt.Dimension(10, 60));
        contenedorr.add(espacio5);

        Contraseña.setBackground(new java.awt.Color(0, 51, 255));
        Contraseña.setForeground(new java.awt.Color(255, 255, 255));
        Contraseña.setText("******");
        Contraseña.setBorder(null);
        Contraseña.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        Contraseña.setMaximumSize(new java.awt.Dimension(750, 60));
        Contraseña.setMinimumSize(new java.awt.Dimension(300, 50));
        Contraseña.setPreferredSize(new java.awt.Dimension(450, 50));
        Contraseña.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                ContraseñaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                ContraseñaFocusLost(evt);
            }
        });
        contenedorr.add(Contraseña);

        PanelContenedor.add(contenedorr);

        Espacio3.setMaximumSize(new java.awt.Dimension(10, 30));
        Espacio3.setMinimumSize(new java.awt.Dimension(10, 30));
        Espacio3.setPreferredSize(new java.awt.Dimension(10, 30));
        PanelContenedor.add(Espacio3);

        Inciairseiosn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Inciairseiosn.setText("Login");
        Inciairseiosn.setAlignmentX(0.5F);
        Inciairseiosn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Inciairseiosn.setMaximumSize(new java.awt.Dimension(750, 60));
        Inciairseiosn.setMinimumSize(new java.awt.Dimension(300, 50));
        Inciairseiosn.setPreferredSize(new java.awt.Dimension(450, 50));
        Inciairseiosn.addActionListener(this::InciairseiosnActionPerformed);
        PanelContenedor.add(Inciairseiosn);

        contenedorcontra.setBackground(new java.awt.Color(0, 51, 255));
        contenedorcontra.setMaximumSize(new java.awt.Dimension(750, 60));
        contenedorcontra.setMinimumSize(new java.awt.Dimension(300, 50));
        contenedorcontra.setPreferredSize(new java.awt.Dimension(450, 55));
        contenedorcontra.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.TRAILING));

        olvidosu.setBackground(new java.awt.Color(0, 51, 255));
        olvidosu.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        olvidosu.setForeground(new java.awt.Color(255, 255, 255));
        olvidosu.setText("¿Olvido su contraseña?");
        olvidosu.setBorder(null);
        olvidosu.setBorderPainted(false);
        olvidosu.setContentAreaFilled(false);
        olvidosu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        olvidosu.setFocusPainted(false);
        olvidosu.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        olvidosu.setMaximumSize(new java.awt.Dimension(750, 60));
        olvidosu.setMinimumSize(new java.awt.Dimension(300, 50));
        olvidosu.setPreferredSize(new java.awt.Dimension(300, 40));
        olvidosu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                olvidosuMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                olvidosuMouseReleased(evt);
            }
        });
        olvidosu.addActionListener(this::olvidosuActionPerformed);
        contenedorcontra.add(olvidosu);

        PanelContenedor.add(contenedorcontra);

        jPanel1.add(PanelContenedor, new java.awt.GridBagConstraints());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1490, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 929, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ContraseñaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_ContraseñaFocusGained

        String pass = new String(Contraseña.getPassword());
        if (pass.equals("******")) {
            Contraseña.setText("");
        }
    }//GEN-LAST:event_ContraseñaFocusGained

    private void ContraseñaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_ContraseñaFocusLost
        String pass = new String(Contraseña.getPassword());
        if (pass.isEmpty()) {
            Contraseña.setText("******");
        }
    }//GEN-LAST:event_ContraseñaFocusLost

    private void InciairseiosnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InciairseiosnActionPerformed
String usuarioIngresado = username.getText();
    String passIngresada = new String(Contraseña.getPassword());

GestionUsuarios gestor = GestionUsuarios.getInstancia();

    Usuario usuarioValidado = gestor.obtenerUsuarioPorCredenciales(usuarioIngresado, passIngresada);
    
    if (usuarioValidado != null) { 
        javax.swing.JOptionPane.showMessageDialog(this, "¡Bienvenido a APUNAB!");

         Ventanamenu menu = new Ventanamenu(usuarioValidado);

        if (this.getExtendedState() == javax.swing.JFrame.MAXIMIZED_BOTH) {
            menu.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        } else {
            menu.setSize(1100, 650); 
            menu.setLocationRelativeTo(null); 
        }
        
        // ==========================================================

        menu.setVisible(true); 
        this.dispose(); 
        
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, "Correo o contraseña incorrectos.", "Error de Login", javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_InciairseiosnActionPerformed

    private void usernameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_usernameFocusGained
        if (username.getText().equals("Correo")) {
            username.setText("");
        }
    }//GEN-LAST:event_usernameFocusGained

    private void usernameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_usernameFocusLost
        if (username.getText().isEmpty()) {
            username.setText("Correo");
        }
    }//GEN-LAST:event_usernameFocusLost

    private void usernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usernameActionPerformed

    private void olvidosuMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_olvidosuMousePressed
        olvidosu.setForeground(new java.awt.Color(200, 200, 200));        // TODO add your handling code here:
    }//GEN-LAST:event_olvidosuMousePressed

    private void olvidosuMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_olvidosuMouseReleased
        olvidosu.setForeground(java.awt.Color.WHITE);        // TODO add your handling code here:
    }//GEN-LAST:event_olvidosuMouseReleased

    private void olvidosuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_olvidosuActionPerformed

    Ventanaregistro registro = new Ventanaregistro();
    registro.setExtendedState(this.getExtendedState());
    registro.setVisible(true);

    this.dispose();
    }//GEN-LAST:event_olvidosuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Ventanainicio().setVisible(true));

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ContenedorIcono;
    private javax.swing.JPasswordField Contraseña;
    private javax.swing.JLabel Espacio1;
    private javax.swing.JLabel Espacio2;
    private javax.swing.JLabel Espacio3;
    private javax.swing.JLabel IconoAPUNAB;
    private javax.swing.JButton Inciairseiosn;
    private javax.swing.JPanel PanelContenedor;
    private javax.swing.JPanel contenedorcontra;
    private javax.swing.JPanel contenedorr;
    private javax.swing.JLabel espacio4;
    private javax.swing.JLabel espacio5;
    private javax.swing.JLabel icono;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton olvidosu;
    private javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables
}
