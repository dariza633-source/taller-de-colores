package appunab;

public class Lugar {
    private String nombre;
    private String ubicacion;
    private String descripcion;
    private String imagenPath;
    private String creadorCorreo; 

    public Lugar(String nombre, String ubicacion, String descripcion, String imagenPath) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.descripcion = descripcion;
        this.imagenPath = imagenPath;
        this.creadorCorreo = null;
    }

    public Lugar(String nombre, String ubicacion, String descripcion, String imagenPath, String creadorCorreo) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.descripcion = descripcion;
        this.imagenPath = imagenPath;
        this.creadorCorreo = creadorCorreo;
    }

    public String getNombre() { return nombre; }
    public String getUbicacion() { return ubicacion; }
    public String getDescripcion() { return descripcion; }
    public String getImagenPath() { return imagenPath; }
    public String getCreadorCorreo() { return creadorCorreo; }
    
    public boolean esFijo() {
        return this.creadorCorreo == null;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Lugar lugar = (Lugar) obj;
        return nombre.equalsIgnoreCase(lugar.nombre);
    }
}