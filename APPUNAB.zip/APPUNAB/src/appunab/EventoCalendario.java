/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appunab;

public class EventoCalendario {
    private int dia;
    private int mes;
    private int anio;
    private String titulo;
    private String tipo; 

    public EventoCalendario(int dia, int mes, int anio, String titulo, String tipo) {
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
        this.titulo = titulo;
        this.tipo = tipo;
    }

    // Getters
    public int getDia() { return dia; }
    public int getMes() { return mes; }
    public int getAnio() { return anio; }
    public String getTitulo() { return titulo; }
    public String getTipo() { return tipo; }
}
